<?php 
defined('C5_EXECUTE') or die("Access Denied.");
$slideshowObj=$controller;

?>

<?php  $this->inc('/form_setup_html.php'); ?> 