<?php  defined('C5_EXECUTE') or die("Access Denied.");
class BlogEntryPageTypeController extends Concrete5_Controller_PageType_BlogEntry {}