<?php 

defined('C5_EXECUTE') or die("Access Denied.");
class DashboardSystemBasicsIconsController extends Concrete5_Controller_Dashboard_System_Basics_Icons {


}