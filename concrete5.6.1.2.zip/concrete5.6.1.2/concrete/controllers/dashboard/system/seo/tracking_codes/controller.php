<?php  defined('C5_EXECUTE') or die("Access Denied.");
class DashboardSystemSeoTrackingCodesController extends Concrete5_Controller_Dashboard_System_Seo_TrackingCodes {}
